<?php
require_once "inc/dbconn.inc.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Dashboard Login Page</title>
    <link rel="stylesheet" href="styles/DaveStyle.css">
</head>

<body>
    <h1 id="loginHeader">Smart Dashboard Login Page</h1>

    <div class="centred-form">
        <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">
            <div class="form-row">
                <label id="labelLogin">Username</label><br>
                <input class="AddForm" type="text" name="username" placeholder="Enter a username">
            </div>
            <div class="form-row">
                <label id="labelLogin">Password</label><br>
                <input class="AddForm" type="password" name="password" placeholder="Enter a password">
            </div>
    </div>
    <div class="centred-btn-container">
        <input class="submit-btn" type="submit" name="submit" value="Login">
    </div>
    </form>
</body>

</html>

<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
    $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);

    if (empty($username)) {
        echo "<p style=\"text-align: center; margin-top: 10px;\">Please enter a username</p>";
    } elseif (empty($password)) {
        echo "<p style=\"text-align: center; margin-top: 10px;\">Please enter a password</p>";
    } else {
        $sql = "SELECT * FROM Users WHERE Username = '$username';";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            if (password_verify($password, $row["PassHash"])) {

                // Establish Session variable for username and 
                // Can be accessed with $_SESSION['Variable']
                
                $_SESSION['User']=$username;

                // Will use this AccountType variable for page security to prevent certain account types from accessing areas that should not be allowed
                // if(isset($_SESSION['AccountType'] != "Admin")) {
                // header("location: index.php")
                // exit();
                // }
                $_SESSION['AccountType']=$row["AccountType"];

                // Dynamically directed to Customised dashboard for specific Account type
                header("location: $row[AccountType]Dashboard.php");
                exit();
            } else {
                echo "<i style=\"color: red\">password incorrect</i></p><br>";
            }
        }else{
            echo "<p style=\"color: red; text-align: center; margin-top:10px;\"><i>User does not exist</i></p><br>";
        }
    }
}

mysqli_close($conn);
?>