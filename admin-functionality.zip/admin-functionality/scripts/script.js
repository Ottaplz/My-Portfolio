const userName = new URLSearchParams(window.location.search).get('name');
const DeleteButton = document.querySelectorAll(".DeleteUser");

// Functions

// Delete confirmation
function confirmdelete() {
    if (window.confirm("Are you sure you want to delete the user?")) {
        return true;
    }
    else
    {
        return false;
    }
}


