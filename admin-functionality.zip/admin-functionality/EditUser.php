<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="author" content="David">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EditUser</title>
    <link rel="stylesheet" href="styles/DaveStyle.css" />
</head>

<body>

    <header>

    <h1>Edit Users</h1>
    <?php 
        session_start();
        echo "Currently logged in as " . $_SESSION['User'];

        echo "<form action=\"/www/admin-functionality/index.php\"> <input class=\"lifter\" type=\"Submit\" value=\"Logout\"> </form>";

        echo "</header>";
        $user = $_GET["Username"];

        // Print user selected from main page information
        require_once "inc/dbconn.inc.php";
        $sql = "SELECT * FROM Users WHERE Username = '$user'";
        echo "<table>\n";
        echo "<tr id=\"display\" class=\"table-header\"> 
                <th id=\"cell-border\">User ID</th> <th id=\"cell-border\">Username</th> <th id=\"cell-border\">AccountType</th> <th id=\"cell-border\">Password Hash</th>
                </tr>";
        if ($result = mysqli_query($conn, $sql) ) {
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr> <td id=\"cell-border\">$row[UserID]</td> <td id=\"cell-border\">$row[Username]</td> <td id=\"cell-border\">$row[AccountType]</td> <td id=\"cell-border\">$row[PassHash]</td>
                            <td> </tr>";
                }  
            }
        }
        echo "</tr>";      
    ?>

    <main>
        <form action="/www/admin-functionality/AdminDashboard.php"> <input id="LiftUp" type="Submit" value="Back to Dashboard"> </form>
        <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">

            <!-- Selector for user -->
            <label>Select a user to edit:</label>
            
            <select class="Selector" id="UserID" name="UserID">
                <?php

                // Any user not an admin will be sent back to the login page
                if($_SESSION['AccountType'] != "Admin") {
                    header("location: index.php");
                    exit();
                }
                
                if (isset($_GET["Username"])) {
                    $user = $_GET["Username"];
                }
                
                // Print user info below 
                $sql = "SELECT UserID, Username, AccountType, PassHash FROM Users;";
                if ($result = mysqli_query($conn, $sql)) {
                    if (mysqli_num_rows($result) > 0) {
                        // Check for and print originally selected user first
                        while ($row = mysqli_fetch_assoc($result)) {
                            if ($row["Username"] == $user) {
                                echo "<option value=\"" . $row["UserID"] . "\" name=\"" . $row["Username"] . "\">" . $row["Username"] . "</option>";
                            }
                        }
                        // Print the rest
                        while ($row = mysqli_fetch_assoc($result)) {
                            if ($row["Username"] == $user) {
                                // Proceed without printing
                            }
                            else {
                                echo "<option value=\"" . $row["UserID"] . "\" name=\"" . $row["Username"] . "\">" . $row["Username"] . "</option>";
                            }
                        }
                        mysqli_free_result($result);
                    }
                }

                ?>
            <!-- Forms for new edit values -->
            </select>
            <br>
            <input class="AddForm" type="text" name="newName" placeholder="Enter a name" />
            <input class="AddForm" type="text" name="newPassword" placeholder="Enter a password" />
            <select class="Selector" id="AccountType" name="AccountType">
                <?php
                echo "<option disabled selected>Select an Account Type</option>";
                $accounttypes = array("Admin", "Operator", "Manager", "Auditor");
                foreach ($accounttypes as $x) {
                    echo "<option value=\"$x\">" . $x . "</option>";
                } 
                ?>   
            </select>   
            <input id="BitRight" type="submit" value="Submit">
        </form>
    </main>
</body>

<footer>
    <p> SMART MANUFACTURING DASHBOARD </p>
</footer>

</html>

<!-- Edit detail logic -->

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    require_once "inc/dbconn.inc.php";

    $UserID  = filter_input(INPUT_POST, "UserID", FILTER_SANITIZE_SPECIAL_CHARS);
    $Username = filter_input(INPUT_POST, "newName", FILTER_SANITIZE_SPECIAL_CHARS);
    $AccountType = filter_input(INPUT_POST, "AccountType", FILTER_SANITIZE_SPECIAL_CHARS);
    $Password = filter_input(INPUT_POST, "newPassword", FILTER_SANITIZE_SPECIAL_CHARS);
    $hash_password = password_hash($Password, PASSWORD_DEFAULT);

    if ($Username) {
        $sql = "UPDATE Users SET Username='$Username' WHERE UserID='$UserID';";
        mysqli_query($conn, $sql);
        echo "<h3 style=\"text-align: center; margin-top: 10px;\">Edit complete</h3>";
    }  
    if ($Password) {
        $sql = "UPDATE Users SET PassHash='$hash_password' WHERE UserID='$UserID';";
        mysqli_query($conn, $sql);
        echo "<h3 style=\"text-align: center; margin-top: 10px;\">Edit complete</h3>";
    }
    if ($AccountType) {
        $sql = "UPDATE Users SET AccountType='$AccountType' WHERE UserID='$UserID';";
        mysqli_query($conn, $sql);
        echo "<h3 style=\"text-align: center; margin-top: 10px;\">Edit complete</h3>";
    }
}


mysqli_close($conn);
?>