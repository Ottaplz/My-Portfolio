SET @@AUTOCOMMIT = 1;

DROP DATABASE IF EXISTS SmartDashboard;
CREATE DATABASE SmartDashboard;

USE SmartDashboard;

CREATE TABLE Users(
    UserID int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Username varchar(100) NOT NULL UNIQUE,
    AccountType enum('Operator', 'Auditor', 'Admin', 'Manager') NOT NULL,
    PassHash varchar(100) NOT NULL,
    updated timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) AUTO_INCREMENT = 1;

CREATE user IF NOT EXISTS dbadmin@localhost;
GRANT all privileges ON SmartDashboard.Users TO dbadmin@localhost;

INSERT INTO Users(Username, AccountType, PassHash) VALUES("Bill Bigsby", "Admin", "$2y$10$qHsF3t7.7FEJqCqrFCBEE.qIAfsSEIp.a7Hcc/01jGrZYJwU8EzoO");
INSERT INTO Users(Username, AccountType, PassHash) VALUES("Warren Jones", "Operator", "$2y$10$fyAvWgZjn/PIrhn9fQ7Kner0vNHOCelTpbAEYYQZ7TivmDnNQCu4i");
INSERT INTO Users(Username, AccountType, PassHash) VALUES("Michael Jackson", "Manager", "$2y$10$Btdqpv3j4iMjdxTPi0H4fu9uJmGE60.C7ahoL/eZdZDRnt28Ql97O");
INSERT INTO Users(Username, AccountType, PassHash) VALUES("Julie Biggums", "Auditor", "$2y$10$pv9uPYGrZLVocIlkHYLanORQNle7HDYfQx4o2.LfLUaf/CnrQjTou");

