<!DOCTYPE html>
<html lang="en">

    <head>
        <meta name="author" content="David">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Management</title>
        <link href="styles/DaveStyle.css" rel="stylesheet" />
    </head>

    <body>
        <header>
        <h1>User Management Dashboard</h1>
        <?php session_start();
        echo "Currently logged in: " . $_SESSION['User'];
        ?>
        <form action="/www/admin-functionality/index.php"> <input class="lifter" type="Submit" value="Logout"> </form>
        </header>

        <?php

        // Any user not an admin will be sent back to the login page
        if($_SESSION['AccountType'] != "Admin") {
            header("location: index.php");
            exit();
        }
        
        require_once "inc/dbconn.inc.php";
        $sql = "SELECT * FROM Users";

        echo "<form id=\"left\" action=\"/www/admin-functionality/AddUser.php\"> <input type=\"Submit\" value=\"Create New User\"> </form>";
        
        if ($result = mysqli_query($conn, $sql) ) {
            if ($rowcount=mysqli_num_rows($result) > 0) {
                echo "<table>\n";
                echo "<tr class=\"table-header\"> 
                <th id=\"cell-border\">User ID</th> <th id=\"cell-border\">Username</th> <th id=\"cell-border\">Account Type</th> <th id=\"cell-border\">Password Hash</th>
                </tr>";
                echo "<ul";
                // Loop Through results in database to print user information and delete / edit buttons
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr> <td id=\"cell-border\">$row[UserID]</td> <td id=\"cell-border\">$row[Username]</td> <td id=\"cell-border\">$row[AccountType]</td> <td id=\"cell-border\">$row[PassHash]</td>
                    <td>
                        <form name=\"editUser\" action=\"EditUser.php\" method=\"GET\"/>  
                            <input type=\"hidden\" class=\"EditView\" name=\"Username\" value=\"$row[Username]\"/> 
                            <input type=\"submit\" class=\"EditView\" name=\"editUser\" value=\"Edit / View\"/>
                        </form>
                    </td>
                    <td>
                        <form name=\"DeleteUser\" action=\"DeleteUser.php\" method=\"POST\"/> 
                            <input type=\"hidden\" class=\"DeleteUser\" name=\"UserID\" value=\"$row[UserID]\"/>                          
                            <input type=\"submit\" class=\"DeleteUser\" name=\"DeleteUser\" value=\"Delete\" onclick=\"return confirmdelete()\"/>
                        </form>
                    </td>   
                        </tr>";
                }
                echo "    </ul>";
                mysqli_free_result($result);
            }
        }
        mysqli_close($conn);
        ?>
        <script src="scripts/script.js" defer></script>
    </body>
    <footer>
        <p> SMART MANUFACTURING DASHBOARD </p>
    </footer>

</html>

