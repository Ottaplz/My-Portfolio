<!-- Logic for deleting a user from database -->
 <!-- Return back to User Managament -->


<?php

if(isset($_POST['DeleteUser'])) 
{

    require_once "inc/dbconn.inc.php";

	$user = filter_input(INPUT_POST, "UserID", FILTER_SANITIZE_SPECIAL_CHARS);

    $sql = "DELETE FROM Users WHERE UserID=$user;";

    mysqli_query($conn, $sql);
    echo "<h3 style=\"text-align: center; margin-top: 10px;\">User deletion complete</h3>";
		
    header("location: AdminDashboard.php");
}
?>