<!-- Page to add new user -->

<!DOCTYPE html>
<html lang="en">

<?php
session_start();
// Any user not an admin will be sent back to the login page
if($_SESSION['AccountType'] != "Admin") {
    header("location: index.php");
    exit();
}
require_once "inc/dbconn.inc.php";
?>

<head>
    <meta name="author" content="David">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AddUser</title>
    <link rel="stylesheet" href="styles/DaveStyle.css" />
</head>

    <body>
    <header>
        <h1>Create New User</h1>
        <?php
        echo "Currently logged in as " . $_SESSION['User'];
        ?>
        <form action="/www/admin-functionality/index.php"> <input class="lifter" type="Submit" value="Logout"> </form>
    </header>
        
        <?php
        echo "<form id=\"AddLeft\" action=\"/www/admin-functionality/AdminDashboard.php\"> <input type=\"Submit\" value=\"Back to Dashboard\"> </form>";
        ?>

        <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">

        <label for="Username">Username</label><br> 
        <input class="AddForm" type="text" name="Username" id="Username" placeholder="Enter a name" required><br>

        <label for="PasswordSet">Initial Password</label><br>
        <input type="text" class="AddForm" name="PasswordSet" id="PasswordSet" placeholder="Enter a password" required><br>

        <select class="Selector" id="AccountType" name="AccountType" required>
                <?php
                echo "<option disabled selected value=\"\">Select an Account Type</option>";
                $accounttypes = array("Admin", "Operator", "Manager", "Auditor");
                foreach ($accounttypes as $x) {
                    echo "<option value=\"$x\">" . $x . "</option>";
                }
                ?>   
            </select> 
            <br>
        <input type="Submit" name="submit" value="Create User">
        
        </form>
    </body>
    
    <footer>
        <p> SMART MANUFACTURING DASHBOARD </p>
    </footer>

</html>

<!-- Add user logic -->

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $Username = filter_input(INPUT_POST, "Username", FILTER_SANITIZE_SPECIAL_CHARS);
    $AccountType = filter_input(INPUT_POST, "AccountType", FILTER_SANITIZE_SPECIAL_CHARS);
    $Password = filter_input(INPUT_POST, "PasswordSet", FILTER_SANITIZE_SPECIAL_CHARS);

    $hash_password = password_hash($Password, PASSWORD_DEFAULT);

    $sql = "SELECT Username FROM Users;";
    if ($result = mysqli_query($conn, $sql)) {
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                if ($Username == $row['Username']) {
                    echo "<h3 style=\"text-align: center; margin-top: 10px;\">User already exists. Please use a different user name</h3>";
                }
                else{
                    $sql = "INSERT INTO Users(Username, AccountType, PassHash) VALUES ('$Username', '$AccountType', '$hash_password');";
                    mysqli_query($conn, $sql);
                    echo "<h3 style=\"text-align: center; margin-top: 10px;\">User creation complete</h3>";
                    mysqli_free_result($result);
                    break;
                }
                
            }
        }
        
    }
}


mysqli_close($conn);
?>